# Two-Weekends-Sans
This is a sans font. The first version was made in two weekends when I was slacking off.
